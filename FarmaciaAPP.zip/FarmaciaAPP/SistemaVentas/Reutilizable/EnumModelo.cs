﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaVentas.Reutilizable
{
    public class EnumModelo
    {
        public enum Modelo
        {
            Producto = 0,
            Tienda = 1,
            Proveedor = 2,
            ProductoTienda = 3
        }
        
    }
}
