﻿using CapaModelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaVentas
{
    public static class Configuracion
    {
        public static Usuario oUsuario { get; set; }
    }
}
